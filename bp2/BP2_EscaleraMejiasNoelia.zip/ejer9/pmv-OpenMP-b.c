#include <stdio.h>
#include <stdlib.h>
#include <omp.h>
#include <time.h>

int main(int argc, char ** argv){
    if (argc != 2){
        printf("Faltan las dimensiones de la matriz y vector\n");
        exit(1);
    }

    int i, j, contador, N = atoi(argv[1]);
    double **m, *v, *resultado, t_inicio, t_fin, parcial=0;

    m = (double **)malloc(N*sizeof(double *));

    for(i=0; i<N; i++){
        m[i] = (double*)malloc(N*sizeof(double));
    }

    resultado = (double *)malloc(N*sizeof(double));

    v = (double*)malloc(N*sizeof(double));

    contador = 0;

    for(i=0; i<N; i++){
        for(j=0; j<N; j++){
            m[i][j] = contador;
            contador++;
        }
    }

    contador = 0;

    for(i=0; i<N; i++){
        v[i] = contador;
        contador++;
    }

    for(i=0; i<N; i++){
        resultado[i] = 0;
    }

    t_inicio = omp_get_wtime();

    #pragma omp parallel private(i) firstprivate(parcial)
    {
        for(i=0; i<N; i++){
            #pragma omp for
            for(j=0; j<N; j++){
                parcial += m[i][j]*v[j];
            }
        
            #pragma omp atomic
            resultado[i] += parcial;
            #pragma omp barrier

            parcial = 0;
        }
    }

    t_fin = omp_get_wtime();

    double tiempo = t_fin - t_inicio;

    if(N<11){
        printf ("Resultados:\n");
        for(i=0; i<N; i++){
            printf("%f ",resultado[i]);
        }
        printf("\n");
    }
    else{
        printf("resultado[0]=%f",resultado[0]);
        printf("\nresultado[N-1]=%f\n",resultado[N-1]);
    }

    printf("Tiempo: %f\n", tiempo);

    free(v);

    for(i=0; i<N; i++){
        free(m[i]);
    }

    free(m);

    free(resultado);

    return (0);
}
